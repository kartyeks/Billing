﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using IRCAKernel;
using System.Reflection;
using BillingManager;
using BillingManager.Forms;
using BillinManager.Forms;
using PDACommunications;

namespace BillingManager.Forms
{
    public partial class BillSummary : Form
    {
        public String StoreId=string.Empty;
        public String BillType = string.Empty;
        private BillController bController=BillController._billController;
        public BillSummary()
        {
            InitializeComponent();
            dtFrom.Value = DateTime.Today;
            dtTo.Value = DateTime.Today;
        }
       

        private void LoadBillSummary(BillSummaryList bsLst)
        {
            grdBill.Rows.Clear();
            grdBill.Rows.Add(bsLst._billSumList.Length);
            int k = 0; double totAmt = 0;
            foreach (BillSummaryDetails bs in bsLst._billSumList)
            {
                DataGridViewRow dr = grdBill.Rows[k];
                dr.Cells["BillID"].Value = bs._billId;
                dr.Cells["BillNumber"].Value = bs._billNumber;
                dr.Cells["BillDate"].Value = bs._billDate;
                dr.Cells["Member"].Value = bs._memberName;
                dr.Cells["MemberID"].Value = bs._memberId;
                dr.Cells["BillAmount"].Value = bs._amount;
                dr.Cells["Counter"].Value = bs._storeCode;
                totAmt = totAmt + bs._amount;
                k++;
            }
            txtTotAmt.Text = totAmt.ToString();
        }
        private void tblSelect_Click(object sender, EventArgs e)
        {
            
            DataGridViewRow crow = grdBill.CurrentRow;
            if (crow == null)
            {
                MessageBox.Show("Select Row","Billing");
                return;
            }
            
            int bId = 0;
            int.TryParse(string.Concat(crow.Cells["BillID"].Value), out bId);
            ((ICMSBill)this.Owner).billId =bId ;
            this.DialogResult = DialogResult.Yes;
            this.Close();
        }

        
        void grdBill_DoubleClick(object sender, System.EventArgs e)
        {
             tblSelect_Click(this.grdBill,new EventArgs());
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            
            BillSummaryList bsList = new BillSummaryList();

            bsList._billNumber = txtBillNumber.Text;
            bsList._fromDate = dtFrom.Value;
            bsList._toDate = dtTo.Value ;
            bsList._storeId = txtPOSID.Text;
            bsList._memberID = txtMemberID.Text;
            bsList._billType = BillType;

            bsList._action = BillActionType.Modify;

            BillSummaryList bslist = bController.GetBillSummary(bsList);
            if (bslist._action == BillActionType.Success)
            {
                LoadBillSummary(bslist);
               // btnFind.Enabled= false;

            }
            else if (bslist._action == BillActionType.Failure)
            {
                MessageBox.Show("Data is not Available", "Billing");
            }
        }

        private void grdBill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tblClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tblClear_Click(object sender, EventArgs e)
        {
            grdBill.Rows.Clear();
            txtBillNumber.Text = "";
            dtFrom.Value = DateTime.Today;
            dtTo.Value = DateTime.Today;
            btnFind.Enabled = true;
            pnlAcChange.Visible = false;
            txtReason.Text = "";
        }

        private void tblBCancel_Click(object sender, EventArgs e)
        {
            DataGridViewRow crow = grdBill.CurrentRow;
            if (crow == null)
            {
                MessageBox.Show("Select Row To Delete Bill", "CMS Billing");
                return;
            }
            lblBillNo.Text = string.Concat(grdBill.CurrentRow.Cells["BillNumber"].Value);
            pnlAcChange.Visible = true;
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            DataGridViewRow crow = grdBill.CurrentRow;
            if (crow == null)
            {
                MessageBox.Show("Select Row To Delete Bill", "CMS Billing");
                return;
            }

            int bId = 0;
            int.TryParse(string.Concat(grdBill.CurrentRow.Cells["BillID"].Value), out bId);
            if (MessageBox.Show("Do you want Delete the Bill? ", "Billing", MessageBoxButtons.YesNo) == DialogResult.No) return;
           /* if (txtReason.Text.Trim() == "")
            {
                MessageBox.Show("Enter Reason", "CMS Billing");
                return;
            }*/
            BillCancel objBill = new BillCancel();
            objBill._billId = bId;
            objBill._reason = txtReason.Text;
            objBill._cancelledDate = DateTime.Now;
            BillController _bController = BillController._billController;
            objBill = _bController.CancelBilling(objBill);
            if (objBill == null) return;
            if (objBill._action == BillActionType.Success)
            {
                MessageBox.Show("Bill Cancelled Successfully");
                grdBill.Rows.Clear();
                txtBillNumber.Text = "";
                dtFrom.Value = DateTime.Today;
                dtTo.Value = DateTime.Today;
                pnlAcChange.Visible = false;
                txtReason.Text = "";
                return;
            }
            else
            {
                MessageBox.Show("Error occured while Cancelling....");
            }
        }

        private void btnCCancel_Click(object sender, EventArgs e)
        {
            pnlAcChange.Visible = false;
            txtReason.Text = "";
        }

        private void BillSummary_Load(object sender, EventArgs e)
        {
            if (!((ICMSBill)this.Owner).hasCancelPerm)
            {
                tblBCancel.Visible = false;
                btnDelete.Visible = false;
                grdBill.Columns["Chk"].Visible = false;
            }
            else
            {
                btnDelete.Visible = true;
                grdBill.Columns["Chk"].Visible = true;
                 
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            grdBill.Rows.Clear();
            txtBillNumber.Text = "";
            txtMemberID.Text="";
            txtPOSID.Text = "";
            dtFrom.Value = DateTime.Today;
            dtTo.Value = DateTime.Today;
            txtReason.Text = "";
            txtTotAmt.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string billIds = string.Empty;
            string billNos = string.Empty;
            foreach (DataGridViewRow dr in grdBill.Rows)
            {
                 if (string.Concat(dr.Cells["Chk"].Value).ToLower() == "true")
                {   
                    billIds=billIds +"," + string.Concat(dr.Cells["BillID"].Value);
                    billNos = billNos + "\n\r" + string.Concat(dr.Cells["BillNumber"].Value);
                }
                    
            }
            if (billIds.Length==0)
            {
                MessageBox.Show("Select Row To Delete Bill", "CMS Billing");
                return;
            }
            billIds = billIds.Substring(1);
            

            //int bId = 0;
            //int.TryParse(string.Concat(grdBill.CurrentRow.Cells["BillID"].Value), out bId);
            if (MessageBox.Show("Do you want Delete the Following Bills? " + billNos , "CMS Billing", MessageBoxButtons.YesNo) == DialogResult.No) return;
             BillCancel objBill = new BillCancel();
            objBill._billIds = billIds;
            objBill._reason = "";
            objBill._cancelledDate = DateTime.Now;
            BillController _bController = BillController._billController;
            objBill = _bController.CancelBilling(objBill);
            if (objBill == null) return;
            if (objBill._action == BillActionType.Success)
            {
                MessageBox.Show("Selected Bills Deleted Successfully");
                grdBill.Rows.Clear();
                txtBillNumber.Text = "";
                txtMemberID.Text = "";
                txtPOSID.Text = "";
                dtFrom.Value = DateTime.Today;
                dtTo.Value = DateTime.Today;
                txtReason.Text = "";
                txtTotAmt.Text = "";
                return;
            }
            else
            {
                MessageBox.Show("Error occured while Cancelling....");
            }
        }
        void txtMemberID_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                System.Windows.Forms.SendKeys.Send("{TAB}");
            }
        }
        void txtBillNumber_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                System.Windows.Forms.SendKeys.Send("{TAB}");
            }
        }

        void txtPOSID_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                System.Windows.Forms.SendKeys.Send("{TAB}");
            }
        }
        void dtFrom_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                System.Windows.Forms.SendKeys.Send("{TAB}");
            }
        }
        void dtTo_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                System.Windows.Forms.SendKeys.Send("{TAB}");
            }
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            DataGridViewRow crow = grdBill.CurrentRow;
            if (crow == null)
            {
                MessageBox.Show("Select Row", "Billing");
                return;
            }

            int bId = 0;
            int.TryParse(string.Concat(crow.Cells["BillID"].Value), out bId);
            ((ICMSBill)this.Owner).billId = bId;
            this.DialogResult = DialogResult.Yes;
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
