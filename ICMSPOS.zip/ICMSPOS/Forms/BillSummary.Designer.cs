﻿namespace BillingManager.Forms
{
    partial class BillSummary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grdBill = new System.Windows.Forms.DataGridView();
            this.mainmenu = new System.Windows.Forms.MenuStrip();
            this.tblSelect = new System.Windows.Forms.ToolStripMenuItem();
            this.tblClose = new System.Windows.Forms.ToolStripMenuItem();
            this.tblClear = new System.Windows.Forms.ToolStripMenuItem();
            this.tblBCancel = new System.Windows.Forms.ToolStripMenuItem();
            this.txtBillNumber = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtTo = new System.Windows.Forms.DateTimePicker();
            this.dtFrom = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFind = new System.Windows.Forms.Button();
            this.pnlAcChange = new System.Windows.Forms.Panel();
            this.grpBillCancel = new System.Windows.Forms.GroupBox();
            this.lblBillNo = new System.Windows.Forms.Label();
            this.btnCCancel = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.txtReason = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMemberID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPOSID = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTotAmt = new System.Windows.Forms.TextBox();
            this.Chk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.BillID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Member = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MemberID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Counter = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.grdBill)).BeginInit();
            this.mainmenu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnlAcChange.SuspendLayout();
            this.grpBillCancel.SuspendLayout();
            this.SuspendLayout();
            // 
            // grdBill
            // 
            this.grdBill.AllowUserToAddRows = false;
            this.grdBill.AllowUserToDeleteRows = false;
            this.grdBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdBill.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Chk,
            this.BillID,
            this.BillNumber,
            this.BillDate,
            this.Member,
            this.MemberID,
            this.BillAmount,
            this.Counter});
            this.grdBill.Location = new System.Drawing.Point(11, 123);
            this.grdBill.Name = "grdBill";
            this.grdBill.Size = new System.Drawing.Size(698, 341);
            this.grdBill.TabIndex = 11;
            this.grdBill.DoubleClick += new System.EventHandler(this.grdBill_DoubleClick);
            this.grdBill.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdBill_CellContentClick);
            // 
            // mainmenu
            // 
            this.mainmenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tblSelect,
            this.tblClose,
            this.tblClear,
            this.tblBCancel});
            this.mainmenu.Location = new System.Drawing.Point(0, 0);
            this.mainmenu.Name = "mainmenu";
            this.mainmenu.Size = new System.Drawing.Size(661, 24);
            this.mainmenu.TabIndex = 15;
            this.mainmenu.Text = "menuStrip1";
            this.mainmenu.Visible = false;
            // 
            // tblSelect
            // 
            this.tblSelect.Name = "tblSelect";
            this.tblSelect.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.tblSelect.Size = new System.Drawing.Size(53, 20);
            this.tblSelect.Text = "&Select ";
            this.tblSelect.Click += new System.EventHandler(this.tblSelect_Click);
            // 
            // tblClose
            // 
            this.tblClose.Name = "tblClose";
            this.tblClose.ShortcutKeys = System.Windows.Forms.Keys.F8;
            this.tblClose.Size = new System.Drawing.Size(48, 20);
            this.tblClose.Text = "&Close";
            this.tblClose.Click += new System.EventHandler(this.tblClose_Click);
            // 
            // tblClear
            // 
            this.tblClear.Name = "tblClear";
            this.tblClear.Size = new System.Drawing.Size(46, 20);
            this.tblClear.Text = "Clear";
            this.tblClear.Click += new System.EventHandler(this.tblClear_Click);
            // 
            // tblBCancel
            // 
            this.tblBCancel.Name = "tblBCancel";
            this.tblBCancel.Size = new System.Drawing.Size(71, 20);
            this.tblBCancel.Text = "Delete Bill";
            this.tblBCancel.Click += new System.EventHandler(this.tblBCancel_Click);
            // 
            // txtBillNumber
            // 
            this.txtBillNumber.Location = new System.Drawing.Point(401, 25);
            this.txtBillNumber.Name = "txtBillNumber";
            this.txtBillNumber.Size = new System.Drawing.Size(112, 20);
            this.txtBillNumber.TabIndex = 3;
            this.txtBillNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBillNumber_KeyDown);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtTo);
            this.groupBox1.Controls.Add(this.dtFrom);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(8, 53);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(339, 45);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Date";
            // 
            // dtTo
            // 
            this.dtTo.CustomFormat = "dd/MM/yyyy";
            this.dtTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTo.Location = new System.Drawing.Point(225, 15);
            this.dtTo.Name = "dtTo";
            this.dtTo.Size = new System.Drawing.Size(104, 20);
            this.dtTo.TabIndex = 5;
            this.dtTo.Value = new System.DateTime(2011, 9, 12, 0, 0, 0, 0);
            this.dtTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtTo_KeyDown);
            // 
            // dtFrom
            // 
            this.dtFrom.CustomFormat = "dd/MM/yyyy";
            this.dtFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtFrom.Location = new System.Drawing.Point(51, 16);
            this.dtFrom.Name = "dtFrom";
            this.dtFrom.Size = new System.Drawing.Size(104, 20);
            this.dtFrom.TabIndex = 4;
            this.dtFrom.Value = new System.DateTime(2011, 9, 12, 0, 0, 0, 0);
            this.dtFrom.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtFrom_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(199, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "To";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "From";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(338, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Bill Number";
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(367, 68);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 23);
            this.btnFind.TabIndex = 6;
            this.btnFind.Text = "Search";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // pnlAcChange
            // 
            this.pnlAcChange.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.pnlAcChange.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnlAcChange.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlAcChange.Controls.Add(this.grpBillCancel);
            this.pnlAcChange.Location = new System.Drawing.Point(202, 239);
            this.pnlAcChange.Name = "pnlAcChange";
            this.pnlAcChange.Size = new System.Drawing.Size(275, 191);
            this.pnlAcChange.TabIndex = 13;
            this.pnlAcChange.Visible = false;
            // 
            // grpBillCancel
            // 
            this.grpBillCancel.Controls.Add(this.lblBillNo);
            this.grpBillCancel.Controls.Add(this.btnCCancel);
            this.grpBillCancel.Controls.Add(this.btnDone);
            this.grpBillCancel.Controls.Add(this.txtReason);
            this.grpBillCancel.Controls.Add(this.Label10);
            this.grpBillCancel.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBillCancel.Location = new System.Drawing.Point(14, 14);
            this.grpBillCancel.Name = "grpBillCancel";
            this.grpBillCancel.Size = new System.Drawing.Size(248, 151);
            this.grpBillCancel.TabIndex = 0;
            this.grpBillCancel.TabStop = false;
            this.grpBillCancel.Text = "Bill Number";
            // 
            // lblBillNo
            // 
            this.lblBillNo.AutoSize = true;
            this.lblBillNo.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillNo.Location = new System.Drawing.Point(39, 30);
            this.lblBillNo.Name = "lblBillNo";
            this.lblBillNo.Size = new System.Drawing.Size(0, 16);
            this.lblBillNo.TabIndex = 0;
            // 
            // btnCCancel
            // 
            this.btnCCancel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnCCancel.Location = new System.Drawing.Point(122, 120);
            this.btnCCancel.Name = "btnCCancel";
            this.btnCCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCCancel.TabIndex = 1;
            this.btnCCancel.Text = "Cancel";
            this.btnCCancel.UseVisualStyleBackColor = false;
            this.btnCCancel.Click += new System.EventHandler(this.btnCCancel_Click);
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnDone.Location = new System.Drawing.Point(15, 120);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 2;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // txtReason
            // 
            this.txtReason.Location = new System.Drawing.Point(15, 44);
            this.txtReason.Multiline = true;
            this.txtReason.Name = "txtReason";
            this.txtReason.Size = new System.Drawing.Size(225, 16);
            this.txtReason.TabIndex = 3;
            this.txtReason.Visible = false;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(14, 28);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(95, 16);
            this.Label10.TabIndex = 4;
            this.Label10.Text = "Enter Reason";
            this.Label10.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Member ID";
            // 
            // txtMemberID
            // 
            this.txtMemberID.Location = new System.Drawing.Point(68, 27);
            this.txtMemberID.Name = "txtMemberID";
            this.txtMemberID.Size = new System.Drawing.Size(121, 20);
            this.txtMemberID.TabIndex = 1;
            this.txtMemberID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMemberID_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(199, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "POS ID";
            // 
            // txtPOSID
            // 
            this.txtPOSID.Location = new System.Drawing.Point(251, 27);
            this.txtPOSID.Name = "txtPOSID";
            this.txtPOSID.Size = new System.Drawing.Size(68, 20);
            this.txtPOSID.TabIndex = 2;
            this.txtPOSID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPOSID_KeyDown);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(448, 68);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(529, 68);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete Bill";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(11, 470);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 9;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(634, 470);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(403, 475);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Total Amount";
            // 
            // txtTotAmt
            // 
            this.txtTotAmt.Location = new System.Drawing.Point(489, 470);
            this.txtTotAmt.Name = "txtTotAmt";
            this.txtTotAmt.ReadOnly = true;
            this.txtTotAmt.Size = new System.Drawing.Size(107, 20);
            this.txtTotAmt.TabIndex = 17;
            this.txtTotAmt.TabStop = false;
            this.txtTotAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Chk
            // 
            this.Chk.HeaderText = "Select";
            this.Chk.Name = "Chk";
            this.Chk.Visible = false;
            this.Chk.Width = 50;
            // 
            // BillID
            // 
            this.BillID.HeaderText = "BillID";
            this.BillID.Name = "BillID";
            this.BillID.ReadOnly = true;
            this.BillID.Visible = false;
            // 
            // BillNumber
            // 
            this.BillNumber.HeaderText = "Bill Number";
            this.BillNumber.Name = "BillNumber";
            this.BillNumber.ReadOnly = true;
            // 
            // BillDate
            // 
            this.BillDate.HeaderText = "Bill Date";
            this.BillDate.Name = "BillDate";
            this.BillDate.ReadOnly = true;
            this.BillDate.Width = 80;
            // 
            // Member
            // 
            this.Member.HeaderText = "Member";
            this.Member.Name = "Member";
            this.Member.ReadOnly = true;
            this.Member.Width = 200;
            // 
            // MemberID
            // 
            this.MemberID.HeaderText = "MemberID";
            this.MemberID.Name = "MemberID";
            this.MemberID.ReadOnly = true;
            this.MemberID.Visible = false;
            // 
            // BillAmount
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.BillAmount.DefaultCellStyle = dataGridViewCellStyle1;
            this.BillAmount.HeaderText = "Bill Amount";
            this.BillAmount.Name = "BillAmount";
            this.BillAmount.ReadOnly = true;
            // 
            // Counter
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Counter.DefaultCellStyle = dataGridViewCellStyle2;
            this.Counter.HeaderText = "Counter";
            this.Counter.Name = "Counter";
            // 
            // BillSummary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(721, 505);
            this.Controls.Add(this.txtTotAmt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPOSID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtMemberID);
            this.Controls.Add(this.pnlAcChange);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtBillNumber);
            this.Controls.Add(this.mainmenu);
            this.Controls.Add(this.grdBill);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BillSummary";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "BIll Summary";
            this.Load += new System.EventHandler(this.BillSummary_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdBill)).EndInit();
            this.mainmenu.ResumeLayout(false);
            this.mainmenu.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlAcChange.ResumeLayout(false);
            this.grpBillCancel.ResumeLayout(false);
            this.grpBillCancel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        

        

        

        

        

        

        #endregion

        private System.Windows.Forms.DataGridView grdBill;
        private System.Windows.Forms.MenuStrip mainmenu;
        private System.Windows.Forms.ToolStripMenuItem tblSelect;
        private System.Windows.Forms.ToolStripMenuItem tblClose;
        private System.Windows.Forms.TextBox txtBillNumber;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtTo;
        private System.Windows.Forms.DateTimePicker dtFrom;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.ToolStripMenuItem tblClear;
        private System.Windows.Forms.ToolStripMenuItem tblBCancel;
        internal System.Windows.Forms.Panel pnlAcChange;
        internal System.Windows.Forms.GroupBox grpBillCancel;
        internal System.Windows.Forms.Button btnCCancel;
        internal System.Windows.Forms.Button btnDone;
        internal System.Windows.Forms.TextBox txtReason;
        internal System.Windows.Forms.Label Label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMemberID;
        private System.Windows.Forms.Label lblBillNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPOSID;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTotAmt;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Chk;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Member;
        private System.Windows.Forms.DataGridViewTextBoxColumn MemberID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Counter;



    }
}